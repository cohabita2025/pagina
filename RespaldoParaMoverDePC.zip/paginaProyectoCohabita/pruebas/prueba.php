<?php
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'] ?? '';
    echo json_encode([
        "status" => "ok",
        "nombre_recibido" => $nombre
    ]);
} else {
    http_response_code(405); // Método no permitido
    echo json_encode([
        "status" => "error",
        "message" => "Solo se permite POST"
    ]);
}
?>
