function enviarDato() {
    // dato simple
    const nombre = "Juan";

    // crear FormData
    const formData = new FormData();
    formData.append("nombre", nombre);

    // enviar a PHP
    fetch("prueba.php", {
        method: "POST",
        body: formData
    })
    .then(res => res.json())
    .then(data => console.log("Respuesta del servidor:", data))
    .catch(err => console.error("Error:", err));
}

// Llamar a la función
enviarDato();
