const parametros = new URLSearchParams(window.location.search);
const personaString = parametros.get("persona");

const persona = JSON.parse(decodeURIComponent(personaString));

console.log(personaString);

document.getElementById("foto-persona").src = `../archivos/familias/${persona.id_familia}/${persona.cedula}/${persona.foto}`;

document.getElementById("nombre-completo").innerHTML = persona.nombre + " " + persona.primer_apellido + " " + persona.segundo_apellido;
document.getElementById("cedula").innerHTML = persona.cedula;

if(persona.genero === "M"){document.getElementById("genero").innerHTML= "Masculino"}else{document.getElementById("genero").innerHTML= "Femenino"}

document.getElementById("fecha-nacimiento").innerHTML= persona.fecha_nacimiento;
document.getElementById("rol-familia").innerHTML= persona.rol_familia;

    document.getElementById("copia-cedula").href=`../archivos/familias/${persona.id_familia}/${persona.cedula}/${persona.copia_cedula}`;
    document.getElementById("copia-cedula").download= `${persona.nombre} ${persona.primer_apellido} ${persona.segundo_apellido} copia cedula`;
    document.getElementById("copia-cedula-nombre").innerHTML= `${persona.nombre} ${persona.primer_apellido} ${persona.segundo_apellido} copia cedula`;

if(persona.telefono !== null){
    console.log("jodida eh")
    document.getElementById("gmail").innerHTML= persona.correo;
    document.getElementById("numero").innerHTML= persona.telefono;
    if(persona.rol === 'titular'){
        document.getElementById("rol-coperativa").innerHTML= "Titular";
    }else if(persona.rol === 'admin'){
        document.getElementById("rol-coperativa").innerHTML= "Admin";
    }else{
        document.getElementById("rol-coperativa").innerHTML= "No tiene rango"
    }

    document.getElementById("comprobante-ingresos").href=`../archivos/familias/${persona.id_familia}/${persona.cedula}/${persona.recibo_sueldo}`;
    document.getElementById("comprobante-ingresos").download= `${persona.nombre} ${persona.primer_apellido} ${persona.segundo_apellido} comprobante ingresos`;
    document.getElementById("comprobante-ingresos-nombre").innerHTML= `${persona.nombre} ${persona.primer_apellido} ${persona.segundo_apellido} comprobante ingresos`;


    document.getElementById("declaracion-no-vivienda").href=`../archivos/familias/${persona.id_familia}/${persona.cedula}/${persona.declaracion_no_vivienda}`;
    document.getElementById("declaracion-no-vivienda").download= `${persona.nombre} ${persona.primer_apellido} ${persona.segundo_apellido}  declaracion no vivienda`;
    document.getElementById("declaracion-no-vivienda-nombre").innerHTML= `${persona.nombre} ${persona.primer_apellido} ${persona.segundo_apellido} declaracion no vivienda`;

}else{
    console.log("muy jodida eh")
    const tapar=document.getElementsByClassName("adulto");
    console.log(tapar);
    for(var i = 0 ; i < tapar.length ; i++){
        console.log(tapar[i]);
        tapar[i].style.display="none";
    }
}


/*
  
{"id_familia":1,
"cedula":"57127887",
"nombre":"agustin",
"primer_apellido":"vannet"
,"segundo_apellido":"antunez",
"genero":"M",
"fecha_nacimiento":"2000-12-31",
"copia_cedula":"copiaCedula_57127887.svg",
"foto":"foto_57127887.svg",
"declaracion_no_vivienda":"declaracion_57127887.svg",
"recibo_sueldo":"recibo_57127887.svg",
"correo":"agusvannet2018@gmail.com",
"telefono":"099999999999999",
"rol":"admin"}
*/