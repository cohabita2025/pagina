function validarDatos(){
    const inputCedula=document.getElementById('cedula');
    const inputContrasenia=document.getElementById('contrasenia');
    var datosValidos=true;
    if(!inputCedula.checkValidity()){
        datosValidos=false;            
        if (!inputCedula.parentNode.classList.contains("invalido")){
            inputCedula.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar una cedula valida.</p>');
            inputCedula.parentNode.classList.add("invalido");
        }
    }else{
        if (inputCedula.parentNode.querySelector("p.mensaje-error") !== null){
            inputCedula.parentNode.classList.remove("invalido");
            inputCedula.parentNode.querySelector("p.mensaje-error").remove();
        }
    }

    if(!inputContrasenia.checkValidity()){
        datosValidos=false;            
        if (!inputContrasenia.parentNode.classList.contains("invalido")){
            inputContrasenia.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar una contraseña valida.</p>');
            inputContrasenia.parentNode.classList.add("invalido");
        }
    }else{
        if (inputContrasenia.parentNode.querySelector("p.mensaje-error") !== null){
            inputContrasenia.parentNode.classList.remove("invalido");
            inputContrasenia.parentNode.querySelector("p.mensaje-error").remove();
        }
    }

    return datosValidos
}


document.querySelector(".datos-titular").addEventListener("submit", async (e) => {
    e.preventDefault();

    if(validarDatos()){
    const inputCedula=document.getElementById('cedula');
    const inputContrasenia=document.getElementById('contrasenia');

    const cedula = document.getElementById("cedula").value.trim();
    const contrasenia = document.getElementById("contrasenia").value.trim();

    // armar formdata
    const formData = new FormData();
    formData.append("cedula", cedula);
    formData.append("contrasenia", contrasenia);

    try {
        const resp = await fetch("../php/iniciar_sesion.php", {
            method: "POST",
            body: formData
        });

        const resultado = (await resp.text()).trim(); // "0", "1", etc.

        // guardar en variable para usar
        const codigo = parseInt(resultado, 10);
        
        // ahora podés usar un switch
        switch (codigo) {
            case 0:
                if (inputCedula.parentNode.querySelector("p.mensaje-error") !== null){
                    inputCedula.parentNode.querySelector("p.mensaje-error").remove();    
                }
                inputCedula.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Cedula no encontrada.</p>');
                inputCedula.parentNode.classList.add("invalido");
                break;
            case 1:
                if (inputCedula.parentNode.querySelector("p.mensaje-error") !== null){
                    inputCedula.parentNode.querySelector("p.mensaje-error").remove();    
                }
                inputCedula.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Familia rechazada.</p>');
                inputCedula.parentNode.classList.add("invalido");
                break;
            case 2:
                if (inputCedula.parentNode.querySelector("p.mensaje-error") !== null){
                    inputCedula.parentNode.querySelector("p.mensaje-error").remove();    
                }
                inputCedula.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Familia pendiente de aprobacion.</p>');
                inputCedula.parentNode.classList.add("invalido");
                break;
            case 3:
                if (inputCedula.parentNode.querySelector("p.mensaje-error") !== null){
                    inputCedula.parentNode.querySelector("p.mensaje-error").remove();    
                }
                inputCedula.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Usuario menor de edad , acceso denegado.</p>');
                inputCedula.parentNode.classList.add("invalido");
                break;
            case 4:
                if (inputContrasenia.parentNode.querySelector("p.mensaje-error") !== null){
                    inputContrasenia.parentNode.querySelector("p.mensaje-error").remove();    
                }
                inputContrasenia.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Cuenta sin contraseña , Ingrese a olvide mi contraseña.</p>');
                inputContrasenia.parentNode.classList.add("invalido");
                break;

            case 5:
                if (inputContrasenia.parentNode.querySelector("p.mensaje-error") !== null){
                    inputContrasenia.parentNode.querySelector("p.mensaje-error").remove();    
                }
                inputContrasenia.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Contraseña erronea.</p>');
                inputContrasenia.parentNode.classList.add("invalido");
                break;
            case 6:
            await guardarFamiliarYSiguiente(cedula, "../html/pagina-principal.html");
            break;
            default:
                console.log(codigo)
                alert("Error inesperado");
        }

    } catch (err) {
        console.error(err);
        alert("⚠️ Error en la conexión con el servidor");
    }
    }
});
