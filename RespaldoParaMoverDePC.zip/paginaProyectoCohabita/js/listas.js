if((usuario.rol !== 'admin') && (usuario.rol !== 'titular')){
    window.location.href="../html/acceso-denegado.html"
}

function dividirListaEnPaginas(objetos) {
    let paginas = [];
    if (objetos.length < 7) {
        console.log("ta chica la lista " + objetos.length);
        paginas.push(objetos); // agregamos todos los objetos como una sola “página”
    } else {
        const cantPaginas = Math.ceil(objetos.length / 7); // ceil para no perder elementos
        for (let x = 0; x < cantPaginas; x++) {
            let paginaActual = [];
            for (let y = 0; y < 7; y++) {
                let indice = x * 7 + y;
                if (objetos[indice] !== undefined) {
                    paginaActual.push(objetos[indice]);
                }
            }
            paginas.push(paginaActual);
        }
    }
    return paginas; // si querés usarlo fuera de la función
}

function cambiarBoton(numero){
    const botonesNumero = document.getElementsByClassName("control-numero");

    for(let boton of botonesNumero){
        boton.disabled = false;
    }

    if(numero === 1){
        document.querySelector(".primer-pagina").disabled = true;
        document.querySelector(".pagina-anterior").disabled = true;
        document.querySelector(".siguiente-pagina").disabled = false;
        document.querySelector(".ultima-pagina").disabled = false;
    } else if(numero === botonesNumero.length){
        document.querySelector(".siguiente-pagina").disabled = true;
        document.querySelector(".ultima-pagina").disabled = true;
        document.querySelector(".primer-pagina").disabled = false;
        document.querySelector(".pagina-anterior").disabled = false;
    }else{
        document.querySelector(".primer-pagina").disabled = false;
        document.querySelector(".pagina-anterior").disabled = false;
        document.querySelector(".siguiente-pagina").disabled = false;
        document.querySelector(".ultima-pagina").disabled = false;
    }

    botonesNumero[numero - 1].disabled = true;
}

function obtenerPaginaActual(){
    const botonesNumero = document.getElementsByClassName("control-numero");
    for(var i =0; i < botonesNumero.length ; i++){
        if(botonesNumero[i].disabled === true){
            console.log(i + "esta es la pagina actual , puede ser o no");
            return i+1;
        }
    }
}


async function filtrarYOrdenar(array, parametros) {
    console.log(" este es el array original " , array)
    var arrayModificado = array;

    // Función auxiliar para acceder a propiedades anidadas usando "a.b.c"
    function getProp(obj, path) {
        return path.split('.').reduce((acc, key) => (acc ? acc[key] : undefined), obj);
    }

    if (parametros) {
        console.log("parametros recibidos");

        // --- ORDENAR ---
        if (parametros.orden) {
            const { orden, variableOrden } = parametros.orden;
            arrayModificado.sort((a, b) => {
                const valA = getProp(a, variableOrden);
                const valB = getProp(b, variableOrden);

                // si son números
                if (!isNaN(valA) && !isNaN(valB)) {
                    return orden === "mayor" ? valB - valA : valA - valB;
                }

                // fechas en formato "YYYY-MM-DD"
                if (/^\d{4}-\d{2}-\d{2}$/.test(valA) && /^\d{4}-\d{2}-\d{2}$/.test(valB)) {
                    return orden === "mayor" ? (valB > valA ? 1 : valB < valA ? -1 : 0)
                                             : (valA > valB ? 1 : valA < valB ? -1 : 0);
                }

                // texto (alfabético)
                if (valA < valB) return orden === "mayor" ? 1 : -1;
                if (valA > valB) return orden === "mayor" ? -1 : 1;
                return 0;
            });
        }

        // --- FILTRO POR CANTIDAD ---
        if (parametros.cantidad) {
            const { cantidad, variableCantidad } = parametros.cantidad;
            arrayModificado = arrayModificado.filter(item => {
                return getProp(item, variableCantidad) === cantidad;
            });
        }

        // --- FILTRO POR ESTADO ---
        if (parametros.estado) {
            const { estado, variableEstado } = parametros.estado;
            arrayModificado = arrayModificado.filter(item => {
                return getProp(item, variableEstado) === estado;
            });
        }

        // --- FILTRO POR BUSQUEDA ---
        if (parametros.buscar) {

            const { buscar, variablesBuscar } = parametros.buscar;
            // Filtrar palabras vacías o con solo espacios
            const palabrasValidas = buscar
            .map(p => p.trim().toLowerCase())
            .filter(p => p.length > 0);
            if (palabrasValidas.length > 0) {
                arrayModificado = arrayModificado.filter(item => {
                    return palabrasValidas.some(palabra => {
                        return variablesBuscar.some(prop => {
                            const valor = getProp(item, prop);
                            return valor && String(valor).toLowerCase().includes(palabra);
                        });
                    });
                });
            }
        }
    }

    console.log(" este es el array modificado " , arrayModificado)

    return arrayModificado;
}


function acomodarControlesLista(lista){
    const listaControles = document.getElementsByClassName("control-numero")
    if(listaControles.length > 1){
        console.log(listaControles , " lista controles")
        console.log(" borrar todo")
        while (listaControles.length > 1) {
            listaControles[1].remove(); // Siempre borramos el segundo elemento hasta que quede solo el primero
        }
    }

    if(lista.length >= 2 ){
    for (var i in lista) {
        numero= +i;
        numero= numero + 1 ;
        if( Number(i) !== 0){
            document.querySelector(".controles-numeros").insertAdjacentHTML('beforeend', `
                <button class="control-numero" onclick="cambiarBoton(${numero}) ;listarPagina(${numero - 1})">
                ${numero}
                </button>
                `);
            }
        }
        document.querySelector(".siguiente-pagina").disabled= false;
        document.querySelector(".ultima-pagina").disabled= false;
    }
}

