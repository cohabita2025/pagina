
var parametros=[];

/*

var parametros = {
  ordenar: {
    orden: "mayor",                     // "mayor" o "menor"
    variableOrden: "titular.nombre"     // propiedad del objeto (puede ser anidada)
  },
  cantidad: {
    cantidad: 3,                        // valor exacto a filtrar
    variableCantidad: "cant_familiares" // propiedad del objeto
  },
  estado: {
    estado: "aprobado",                 // valor a comparar (ej. "aprobado", "rechazado")
    variableEstado: "estado"            // propiedad del objeto
  },
  buscar: {
    buscar: ["ju", "pe"],               // palabras a buscar (no distingue mayúsculas/minúsculas)
    variablesBuscar: [
      "titular.nombre",
      "titular.primer_apellido",
      "titular.segundo_apellido"
    ]                                   // propiedades en las que buscar
  }
};

*/

function actualizarParametros(){
    console.log(" estos son los parametros originales" , parametros)
    var parametrosActualizados={};

    var orden= {
        orden : "",
        variableOrden :""
    }
    var cantidad= {
        cantidad: "",                        
        variableCantidad: "" 
    }

    var estado= {
        estado: "",                        
        variableEstado: "" 
    }

    var buscar= {
        buscar: [""],                        
        variablesBuscar: [""] 
    }

    switch (document.getElementById('orden').querySelector("select").value){
        case '1':
            orden.orden='menor';
            orden.variableOrden='fecha_envio';
            parametrosActualizados.orden = orden;
            break;
        
        case '2':
            orden.orden='mayor';
            orden.variableOrden='fecha_envio';
            parametrosActualizados.orden = orden;
            break;
        
        case '4':
            orden.orden='menor';
            orden.variableOrden='monto';
            parametrosActualizados.orden = orden;
            break;
        
        case '3':
            orden.orden='mayor';
            orden.variableOrden='monto';
            parametrosActualizados.orden = orden;
            break;
        
    }

    if(document.getElementById("cant-integrantes").value !== "0"){
        cantidad.cantidad=Number(document.getElementById("cant-integrantes").value);                        
        cantidad.variableCantidad="monto";
        parametrosActualizados.cantidad = cantidad;
    }
    
    switch (document.getElementById('estado').querySelector("select").value){
        case '2':
            estado.estado='aprobado';
            estado.variableEstado='estado';
            parametrosActualizados.estado = estado;
            break;
        
        case '3':
            estado.estado='rechazado';
            estado.variableEstado='estado';
            parametrosActualizados.estado = estado;
            break;
        
        case '4':
            estado.estado='pendiente';
            estado.variableEstado='estado';
            parametrosActualizados.estado = estado;
            break;
        
    }

    if(document.getElementById("buscador").value.length > 0){
        buscar.buscar = document.getElementById("buscador").value.split(" ");
        buscar.variablesBuscar= ["adulto.nombre" , "adulto.primer_apellido" , "adulto.segundo_apellido"];
        parametrosActualizados.buscar = buscar;
    }

    parametros=parametrosActualizados;
    console.log(" estos son los parametros actualizados" , parametros)
}



// Función para traer todas las solicitudes con su titular
async function obtenerSolicitudes() {
    try {
        // Llamamos al PHP que genera el JSON
        const response = await fetch('../php/obtener_comprobantes_pago.php', {
            method: 'GET'
        });

        if (!response.ok) {
            throw new Error(`Error HTTP: ${response.status}`);
        }

        // Parseamos el JSON
        const datos = await response.json();

        // Retornamos el arreglo de solicitudes
        return datos;


    } catch (error) {
        console.error("Error al obtener solicitudes:", error);
        return []; // Retornamos un arreglo vacío en caso de error
    }
}
async function cargarSolicitudes() {
    console.log("entra a la seccion 01");
    comprobantes = await filtrarYOrdenar(await obtenerSolicitudes(), parametros); // Llama al PHP y obtiene los datos


    if(comprobantes.length > 7){
        console.log("mas de 7 solis")
        listaComprobantes = dividirListaEnPaginas(comprobantes); // Divide en páginas
    }else{
        listaComprobantes = comprobantes;
        console.log("menos de 7 solis")
    }
    // Ahora que los datos están listos, podemos listar la primera página
    listarPaginas(0 ,listaComprobantes);
    acomodarControlesLista(dividirListaEnPaginas(comprobantes));

    console.log("prueba lista" ,listaComprobantes)

}
// Llamamos a la función
cargarSolicitudes();
async function listarPagina (num) {
    comprobantes = await filtrarYOrdenar(await obtenerSolicitudes(), parametros); // Llama al PHP y obtiene los datos

    listaComprobantes = dividirListaEnPaginas(comprobantes); // Divide en páginas

    console.log("hola soy goku",listaComprobantes)
    listarPaginas(num ,listaComprobantes);
    console.log ("listar pagina dice " + num , listaComprobantes)
}

function listarPaginas(num , listar){
    console.log(listar)
    var lista= document.querySelector(".lista-real");
    

    lista.innerHTML = "";
    if(listar[num][0] !== undefined){
        listar=listar[num];
    }else{
        listar=listar;
    }
    
    console.log("la lista EEEEEEEEEEEEEEEEEEEEESSSSSSSSSSSS " , listar)


    for(var i = 0; i < listar.length ; i++){
        console.log("esta es la solicitud "+ i  , listar[i])
        switch(listar[i].estado){
            case "aprobado":
                lista.insertAdjacentHTML('beforeend', `
                <div class="solicitud-registro">
                        <div class="fecha">
                            <p>${listar[i].fecha_envio}</p>
                        </div>

                        <div class="separador"></div> 

                        <div class="nombreTitular">
                            <p>${listar[i].adulto.nombre.toUpperCase()} ${listar[i].adulto.primer_apellido.toUpperCase()} ${listar[i].adulto.segundo_apellido.toUpperCase()}</p>
                        </div>

                        <div class="separador"></div>

                        <div class="cantIntegrantes">
                            <p>${listar[i].monto}</p>
                        </div>

                        <div class="separador"></div>
                        
                        <div class="estadoSolicitud">
                            <p class="${listar[i].estado}">Aprobado</p>
                        </div>
                        
                        <div class="separador"></div>
                        
                        <button class="botonSolicitud estado_aprobado" onclick="mostrarDatosAporte(${listar[i].id})">
                            Ver solicitud
                        </button>

                    </div>
                `);
                break;
            case "rechazado":
                lista.insertAdjacentHTML('beforeend', `
                <div class="solicitud-registro">
                        <div class="fecha">
                            <p>${listar[i].fecha_envio}</p>
                        </div>

                        <div class="separador"></div>

                        <div class="nombreTitular">
                            <p>${listar[i].adulto.nombre.toUpperCase()} ${listar[i].adulto.primer_apellido.toUpperCase()} ${listar[i].adulto.segundo_apellido.toUpperCase()}</p>
                        </div>

                        <div class="separador"></div>

                        <div class="cantIntegrantes">
                            <p>${listar[i].monto}</p>
                        </div>

                        <div class="separador"></div>
                        
                        <div class="estadoSolicitud">
                            <p class="${listar[i].estado}">Rechazado</p>
                        </div>
                        
                        <div class="separador"></div>
                        
                        <button class="botonSolicitud estado_rechazado" onclick="mostrarDatosAporte(${listar[i].id})">
                            Ver solicitud
                        </button>

                    </div>
                `);
                break;

            case "pendiente":
                lista.insertAdjacentHTML('beforeend', `
                <div class="solicitud-registro">
                        <div class="fecha">
                            <p>${listar[i].fecha_envio}</p>
                        </div>

                        <div class="separador"></div>

                        <div class="nombreTitular">
                            <p>${listar[i].adulto.nombre.toUpperCase()} ${listar[i].adulto.primer_apellido.toUpperCase()} ${listar[i].adulto.segundo_apellido.toUpperCase()}</p>
                        </div>

                        <div class="separador"></div>

                        <div class="cantIntegrantes">
                            <p>${listar[i].monto}</p>
                        </div>

                        <div class="separador"></div>
                        
                        <div class="estadoSolicitud">
                            <p class="${listar[i].estado}">Pendiente</p>
                        </div>
                        
                        <div class="separador"></div>
                        
                        <button class="botonSolicitud estado_pendiente" onclick="mostrarDatosAporte(${listar[i].id})">
                            Iniciar votacion
                        </button>

                    </div>
                `);
                break;

            case "en_votacion":

            //existen 2 estados falta diferenciarlos

                lista.insertAdjacentHTML('beforeend', `
                <div class="solicitud-registro">
                        <div class="fecha">
                            <p>${listar[i].fecha_envio}</p>
                        </div>

                        <div class="separador"></div>

                        <div class="nombreTitular">
                            <p>${listar[i].nombre.toUpperCase()} ${listar[i].primer_apellido.toUpperCase()} ${listar[i].segundo_apellido.toUpperCase()}</p>
                        </div>

                        <div class="separador"></div>

                        <div class="cantIntegrantes">
                            <p>${listar[i].monto}</p>
                        </div>

                        <div class="separador"></div>
                        
                        <div class="estadoSolicitud">
                            <p class="${listar[i].estado}">En votacion ${listar[i].evaluaciones}/${listar[i].admins}</p>
                        </div>
                        
                        <div class="separador"></div>
                        
                        <button class="botonSolicitud estado_en_votacion" onclick="mostrarDatosAporte(${listar[i].id})">
                            Votar / Voto emitido
                        </button>

                    </div>
                `);
                break;
        }
        

                console.log("solicitud impresa =" + num + " - "+ i);
    }
}

function accederEvaluacionSolicitud(idsolicitud){
    console.log(idsolicitud + " esta es la solicitud")
}

async function mostrarDatosAporte(id){ 
    sessionStorage.setItem("comprobante", JSON.stringify(id));
    window.location = "../html/evaluar-comprobante-pago.html";
}