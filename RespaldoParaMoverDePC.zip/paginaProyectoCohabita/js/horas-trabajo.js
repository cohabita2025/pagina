function validarDatos(){
    var datosValidos=true;
    const mes = document.getElementById("mesInput");
    const actividad = document.getElementById("actividad");
    const horaEntrada = document.getElementById("horaEntrada");
    const horaSalida = document.getElementById("horaSalida");
    const minutoEntrada = document.getElementById("minutoEntrada");
    const minutoSalida = document.getElementById("minutoSalida");

    if(!mes.checkValidity()){
        datosValidos=false;            
        if (!mes.parentNode.parentNode.parentNode.classList.contains("invalido")){
            mes.parentNode.parentNode.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar un mes valido.</p>');
            mes.parentNode.parentNode.parentNode.classList.add("invalido");
        }
    }else{
        console.log("eso")
        if (mes.parentNode.parentNode.parentNode.querySelector("p.mensaje-error") !== null){
            console.log("josesu")
            mes.parentNode.parentNode.parentNode.classList.remove("invalido");
            mes.parentNode.parentNode.parentNode.querySelector("p.mensaje-error").remove();
        }
    }
    

    if(!actividad.checkValidity()){
        datosValidos=false;            
        if (!actividad.parentNode.classList.contains("invalido")){
            actividad.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar una actividad valida.</p>');
            actividad.parentNode.classList.add("invalido");
        }
    }else{
        if (actividad.parentNode.querySelector("p.mensaje-error") !== null){
            actividad.parentNode.classList.remove("invalido");
            actividad.parentNode.querySelector("p.mensaje-error").remove();
        }
    }

    if((horaEntrada.value === horaSalida.value ) && (minutoEntrada.value === minutoSalida.value)){
        datosValidos=false;            
        if (!horaEntrada.parentNode.classList.contains("invalido")){
            horaEntrada.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error"> Ingresa una hora valida.</p>');
            horaEntrada.parentNode.classList.add("invalido");
            horaSalida.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Ingresa una hora valida.</p>');
            horaSalida.parentNode.classList.add("invalido");
        }
    }else{
        if (horaEntrada.parentNode.querySelector("p.mensaje-error") !== null){
            horaEntrada.parentNode.classList.remove("invalido");
            horaEntrada.parentNode.querySelector("p.mensaje-error").remove();
            horaSalida.parentNode.classList.remove("invalido");
            horaSalida.parentNode.querySelector("p.mensaje-error").remove();
        }
    }

    return datosValidos
 }


// Función para reunir datos y enviarlos
async function reunirDatos(event) {
    if (validarDatos()) {
        if (await confirmarAccion('¿Enviar?')) {

            const dia = document.getElementById("dia").value.padStart(2, "0");
            const mes = document.getElementById("mesInput").value.padStart(2, "0");
            const anio = document.getElementById("anio").value;

            // tomo los valores y los convierto a enteros (seguro contra cadenas vacías)
            const horaEntrada = parseInt(document.getElementById("horaEntrada").value || "0", 10);
            const minutoEntrada = parseInt(document.getElementById("minutoEntrada").value || "0", 10);
            const horaSalida = parseInt(document.getElementById("horaSalida").value || "0", 10);
            const minutoSalida = parseInt(document.getElementById("minutoSalida").value || "0", 10);

            const tarea = document.querySelector(".input-texto textarea").value;

            // Cédula del adulto desde usuario.cedula
            const cedula_adulto = usuario.cedula;

            // Creamos la fecha de entrada con la fecha seleccionada y la hora de entrada
            const fechaEntrada = new Date(`${anio}-${mes}-${dia}T${String(horaEntrada).padStart(2,"0")}:${String(minutoEntrada).padStart(2,"0")}:00`);

            // calculamos diferencia en minutos entre entrada y salida (solo por horas/minutos)
            const entradaMin = horaEntrada * 60 + minutoEntrada;
            const salidaMin = horaSalida * 60 + minutoSalida;
            let diffMin = salidaMin - entradaMin;

            // si es negativa, asumimos que la salida fue al día siguiente
            if (diffMin < 0) diffMin += 24 * 60;

            // ahora calculamos la fechaSalida basándonos en fechaEntrada + diffMin
            const fechaSalida = new Date(fechaEntrada.getTime() + diffMin * 60 * 1000);

            // Cantidad de horas en formato decimal (2 decimales)
            const cantHoras = (diffMin / 60).toFixed(2);

            // Fecha del aporte (hoy)
            const fecha_aporte = new Date().toISOString().split('T')[0]; // YYYY-MM-DD

            // FormData para enviar
            const formData = new FormData();
            formData.append("fecha_aporte", fecha_aporte);
            formData.append("tarea", tarea);
            formData.append("cedula_adulto", cedula_adulto);
            formData.append("cant_horas", cantHoras);
            // fecha_horas se envía como DATETIME (usás la fecha de entrada)
            formData.append("fecha_horas", fechaEntrada.toISOString().slice(0, 19).replace("T", " ")); // DATETIME

            try {
                const response = await fetch("../php/horas_semanales.php", {
                    method: "POST",
                    body: formData
                });

                const data = await response.json();
                if (data.error) {
                    alert("Error: " + data.error);
                } else {
                    redirigir("pagina-principal.html", "agregar-horas-trabajo.html", "Volver al inicio", "Enviar mas horas de trabajo");
                }

            } catch (error) {
                console.error("Error al enviar datos:", error);
                alert("No se pudo registrar las horas.");
            }
        }
    }
}


// Calcular y mostrar total de horas en tiempo real
function actualizarTotalHoras() {
    const horaEntrada = parseInt(document.getElementById("horaEntrada")?.value || "0", 10);
    const minutoEntrada = parseInt(document.getElementById("minutoEntrada")?.value || "0", 10);
    const horaSalida = parseInt(document.getElementById("horaSalida")?.value || "0", 10);
    const minutoSalida = parseInt(document.getElementById("minutoSalida")?.value || "0", 10);

    // Convertir todo a minutos
    const entradaMin = horaEntrada * 60 + minutoEntrada;
    const salidaMin = horaSalida * 60 + minutoSalida;

    // Diferencia en minutos
    let diffMin = salidaMin - entradaMin;

    // Si es negativa, pasó al día siguiente
    if(diffMin < 0) diffMin += 24 * 60;

    const cantHoras = (diffMin / 60).toFixed(2);

    const totalHorasEl = document.getElementById("total-horas");
    if (totalHorasEl) totalHorasEl.innerText = cantHoras;
}



// Escuchar cambios para actualizar total
["horaEntrada","minutoEntrada","horaSalida","minutoSalida"].forEach(id => {
    document.getElementById(id).addEventListener("input", actualizarTotalHoras);
});

// Asignar evento al formulario
document.querySelector(".menu-horas").addEventListener("submit", reunirDatos);
