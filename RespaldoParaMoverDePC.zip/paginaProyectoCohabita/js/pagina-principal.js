const usuario = obtenerFamiliarGuardado();

if (usuario == null) { 
    console.log("Usuario no existe");
    window.location.href = "../html/acceso-denegado.html";
}

/*
                <img src="" alt="" id="foto-usuario">
                <p id="nombre-usuario">AGUSTIN VANNET ANTUNEZ    </p>
                <img src="../archivos/imagenes/flechita.svg" alt="">

*/

/*
switch (usuario.rol) {
    case "titular":
        mostrarItems("li.titular");
        break;
    case "admin":
        mostrarItems("li.admin");
        break;
}
*/

const usuarioNombreCompleto = (usuario.nombre + " " + usuario.primer_apellido + " " + (usuario.segundo_apellido || ""))
      .toUpperCase();
document.getElementById("nombre-usuario").innerHTML = usuarioNombreCompleto;

document.getElementById("foto-usuario").src = `../archivos/familias/${usuario.id_familia}/${usuario.cedula}/${usuario.foto}`;

