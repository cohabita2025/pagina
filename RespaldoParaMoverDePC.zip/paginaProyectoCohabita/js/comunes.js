function simularClick(id){
    document.getElementById(id).click();
}

function formatearInput(id){
    document.getElementById(id).value="";
}

function sincronizarNombreInput (input) {
    document.getElementById(input + "Parrafo").innerHTML = document.getElementById(input).files[0].name;
}

function sincronizarFotoInput(idInput) {
  const input = document.getElementById(idInput);
  const file = input.files[0];
  const defaultImg = "../archivos/imagenes/personaVacia.svg"; // imagen por defecto

  // Imagen en el bloque de edición (informacion-completa)
  const imgEdicion = input.closest(".foto").querySelector("img");

  // Imagen en el bloque de vista previa (informacion-basica)
  const imgBasica = input.closest(".informacion-completa")
                         .previousElementSibling
                         .querySelector("img");

  if (file) {
    const url = URL.createObjectURL(file);
    imgEdicion.src = url;
    imgBasica.src = url;
  } else {
    // Si no hay archivo, volver a la imagen por defecto
    imgEdicion.src = defaultImg;
    imgBasica.src = defaultImg;
  }
}


function seleccionOpcion(id , value){
    document.getElementById(id).getElementsByClassName("select-oculto")[0].value=value;
    document.getElementById(id).getElementsByClassName("valorSeleccionado")[0].style.display='block';
    document.getElementById(id).getElementsByClassName("valorSeleccionado")[0].innerHTML=document.getElementById(id).querySelector(`option[value="${value}"]`).innerHTML
} 

function desplegarFamiliar (familiar){
    const informacionBasica = document.getElementById(familiar).querySelector(".informacion-basica");
    const informacionCompleta = document.getElementById(familiar).querySelector(".informacion-completa");

    if(informacionBasica.style.display == 'none'){

        const nombre  = informacionCompleta.querySelector(".nombre").value;
        const primerApellido  =informacionCompleta.querySelector(".primer-apellido").value
        const segundoApellido  =informacionCompleta.querySelector(".segundo-apellido").value

        if ( nombre != "" && primerApellido != ""){
        informacionBasica.querySelector(".nombre-completo").innerHTML = nombre + " " + primerApellido + " " + segundoApellido
        }else{
            informacionBasica.querySelector(".nombre-completo").innerHTML = "nombre completo familiar"
        }
        informacionBasica.style.display = 'flex';
        informacionCompleta.style.display = 'none';
    }else{
        informacionBasica.style.display = 'none';
        informacionCompleta.style.display = 'flex';
    }

}

function mostrarOcultarContrasenia(idInput) {
        const input = document.getElementById(idInput);
        const ocultarImg = input.parentNode.querySelector(".ocultar-contrasenia");
        const mostrarImg = input.parentNode.querySelector(".mostrar-contrasenia");

    if( input.type == 'password' ){
        input.type = 'text';
        mostrarImg.style.display='block';
        ocultarImg.style.display='none';
    }else{
        input.type = 'password' ;
        mostrarImg.style.display='none';
        ocultarImg.style.display='block';
    }

}

function HabilitarDesabilitarBotones(familiar , decision){
    //comprobante , declaracion , gmail , numero 

    const comprobante = document.getElementById(familiar).querySelector('.input-comprobante-ingresos')
    const declaracion = document.getElementById(familiar).querySelector('.input-declaracion-no-vivienda')
    const gmail = document.getElementById(familiar).querySelector('.input-gmail')
    const numero = document.getElementById(familiar).querySelector('.input-numero-telefonico')

    if(decision === 'desabilitar'){
        comprobante.disabled=true;
        declaracion.disabled=true;
        gmail.disabled=true;
        numero.disabled=true;

        gmail.value="";
        numero.value='';

        gmail.parentNode.classList.add("desabilitado");
        numero.parentNode.classList.add("desabilitado");
        declaracion.parentNode.classList.add("desabilitado");
        comprobante.parentNode.classList.add("desabilitado");
    }else{
        comprobante.disabled=false;
        declaracion.disabled=false;
        gmail.disabled=false;
        numero.disabled=false;

        gmail.parentNode.classList.remove("desabilitado");
        numero.parentNode.classList.remove("desabilitado");
        declaracion.parentNode.classList.remove("desabilitado");
        comprobante.parentNode.classList.remove("desabilitado");
    }
}

function compararFechaEdad(idDia, idMes, idAnio, familiar) {
    const dia = parseInt(document.getElementById(idDia).value, 10);
    const mes = parseInt(document.getElementById(idMes).querySelector('select').value, 10) - 1; // JS cuenta 0-11
    const anio = parseInt(document.getElementById(idAnio).value, 10);

    const hoy = new Date();
    const fechaNacimiento = new Date(anio, mes, dia);

    const diferencia = hoy - fechaNacimiento; // hoy - nacimiento
    const edad = Math.floor(diferencia / (1000 * 60 * 60 * 24 * 365.25));


    if(edad < 18){
        console.log("menor de edad");
        HabilitarDesabilitarBotones(familiar , 'desabilitar');

    }else{
        console.log("mayor de edad");
        HabilitarDesabilitarBotones(familiar , 'habilitar');
    }

}


function acomodarAnio(id){
    const hoy = new Date();
    const anioActual = hoy.getFullYear();

    input = document.getElementById(id);

    const anio = parseInt(input.value , 10)
    if(anio > anioActual ){
        input.value=anioActual;
    }
}

function eliminarFamiliar(familiar){
    if(document.getElementsByClassName('familiar').length > 1){
        document.getElementById(familiar).remove();
    }
}


let cantFamiliares=1;

function agregarFamiliar(){
    cantFamiliares++;

    document.querySelector(".lista-familiares").insertAdjacentHTML('afterbegin', `

        <div class="familiar" id="familiar${cantFamiliares}">
        <div class="informacion-basica">
        <img src="../archivos/imagenes/personaVacia.svg" alt="foto" class="imgFamiliar${cantFamiliares}">
                        <p class="nombre-completo">nombre completo del familiar</p>

                        <button class="eliminar boton-simple-azul" type="button" onclick="eliminarFamiliar('familiar${cantFamiliares}')">
                            Eliminar
                        </button>
                    </div>

                    <div class="informacion-completa">
                        <div class="foto">
                            <img src="../archivos/imagenes/personaVacia.svg" alt="foto" class="imgFamiliar${cantFamiliares}">

                            <div class="input-archivo">
                                <input type="file" class="input-foto" id="fotoFamiliar${cantFamiliares}" onchange="sincronizarNombreInput('fotoFamiliar${cantFamiliares}') ; sincronizarFotoInput('fotoFamiliar${cantFamiliares}')" required>
                                <button type="button" class="falso-input" onclick="simularClick('fotoFamiliar${cantFamiliares}')" >Selecciona la foto del familiar</button>

                                <div class="edicion-archivo">
                                    <p id="fotoFamiliar${cantFamiliares}Parrafo"></p>
                                    <button type="button" class="borrar" onclick="formatearInput('fotoFamiliar${cantFamiliares}') ; sincronizarFotoInput('fotoFamiliar${cantFamiliares}')">
                                        <img src="../archivos/imagenes/SimboloTachar.svg" alt="">
                                    </button>
                                </div>

                            </div>
                        </div>

                        <div class="datos">
                            <div class="input-texto">
                                <input type="text" id="nombre${cantFamiliares}" class="nombre" minlength="2" maxlength="20" placeholder=" " required oninput="this.value = this.value.replace(/[^a-zA-Z]/g,'')">
                                <label for="nombre${cantFamiliares}">Nombre</label>
                            </div>

                            <div class="input-texto">
                                <input type="text" id="primer-apellido${cantFamiliares}" class="primer-apellido" minlength="2" maxlength="20" placeholder=" " required oninput="this.value = this.value.replace(/[^a-zA-Z]/g,'')">
                                <label for="primer-apellido${cantFamiliares}">Primer apellido</label>
                            </div>

                            <div class="input-texto">
                                <input type="text" id="segundo-apellido${cantFamiliares}" class="segundo-apellido" minlength="2" maxlength="20" placeholder=" " oninput="this.value = this.value.replace(/[^a-zA-Z]/g,'')">
                                <label for="segundo-apellido${cantFamiliares}">Segundo apellido</label>
                            </div>

                            <div class="input-texto">
                                <input type="text" class="cedula" id="cedula${cantFamiliares}" placeholder=" "  minlength="8" maxlength="8" required oninput="this.value = this.value.replace(/\\D/g,'')">
                                <label for="cedula${cantFamiliares}">Cedula</label>
                            </div>

                            <div class="input-fecha">
                                <p class="tipo-fecha">Fecha de nacimiento</p>
                                <div class="inputs-fecha">
                                    <input type="text" class="input-dia" name="" id="dia${cantFamiliares}" value="31" min="1" maxlength="2" minlength="1" required oninput="if(this.value===''){this.value='1'} ; compararFechaEdad('dia${cantFamiliares}', 'mes${cantFamiliares}' , 'anio${cantFamiliares}' , 'familiar${cantFamiliares}') ; this.value = this.value.replace(/\D/g,'') ; if( parseInt(this.value , 10) > 31) this.value = 31   ; arreglarFecha('mes${cantFamiliares}' , 'dia${cantFamiliares}','anio${cantFamiliares}')"> 
                                    <p>de</p>

                                    <div class="desplegable" tabindex="0" id="mes${cantFamiliares}">
                                        <select class="select-oculto select-mes" required >

                                            <option value="">titulo</option>
                                            <option value="1" >Enero</option>
                                            <option value="2">Febrero</option> 
                                            <option value="3">Marzo</option>
                                            <option value="4">Abril</option> 
                                            <option value="5">Mayo</option>
                                            <option value="6">Junio</option> 
                                            <option value="7">Julio</option>
                                            <option value="8">Agosto</option> 
                                            <option value="9">Septiembre</option>
                                            <option value="10">Octubre</option> 
                                            <option value="11">Noviembre</option>
                                            <option value="12">Diciembre</option> 

                                        </select>
                                        <p class="tipoDesplegable">Mes</p>
                                        <p class="valorSeleccionado"></p>
                                        <ul class="opciones">
                                            <li class="opcion" data-value="1" onclick="seleccionOpcion('mes${cantFamiliares}' , 1) ; compararFechaEdad('dia${cantFamiliares}', 'mes${cantFamiliares}' , 'anio${cantFamiliares}', 'familiar${cantFamiliares}')  ; arreglarFecha('mes${cantFamiliares}' , 'dia${cantFamiliares}','anio${cantFamiliares}')">Enero</li>
                                            <li class="separador">.</li>
                                            <li class="opcion" data-value="2" onclick="seleccionOpcion('mes${cantFamiliares}' , 2) ; compararFechaEdad('dia${cantFamiliares}', 'mes${cantFamiliares}' , 'anio${cantFamiliares}', 'familiar${cantFamiliares}')  ; arreglarFecha('mes${cantFamiliares}' , 'dia${cantFamiliares}','anio${cantFamiliares}')">Febrero</li>
                                            <li class="separador">.</li>
                                            <li class="opcion" data-value="3" onclick="seleccionOpcion('mes${cantFamiliares}' , 3) ; compararFechaEdad('dia${cantFamiliares}', 'mes${cantFamiliares}' , 'anio${cantFamiliares}', 'familiar${cantFamiliares}')  ; arreglarFecha('mes${cantFamiliares}' , 'dia${cantFamiliares}','anio${cantFamiliares}')">Marzo</li>
                                            <li class="separador">.</li>
                                            <li class="opcion" data-value="4" onclick="seleccionOpcion('mes${cantFamiliares}' , 4) ; compararFechaEdad('dia${cantFamiliares}', 'mes${cantFamiliares}' , 'anio${cantFamiliares}', 'familiar${cantFamiliares}')  ; arreglarFecha('mes${cantFamiliares}' , 'dia${cantFamiliares}','anio${cantFamiliares}')">Abril</li>
                                            <li class="separador">.</li>
                                            <li class="opcion" data-value="5" onclick="seleccionOpcion('mes${cantFamiliares}' , 5) ; compararFechaEdad('dia${cantFamiliares}', 'mes${cantFamiliares}' , 'anio${cantFamiliares}', 'familiar${cantFamiliares}')  ; arreglarFecha('mes${cantFamiliares}' , 'dia${cantFamiliares}','anio${cantFamiliares}')">Mayo</li>
                                            <li class="separador">.</li>
                                            <li class="opcion" data-value="6" onclick="seleccionOpcion('mes${cantFamiliares}' , 6) ; compararFechaEdad('dia${cantFamiliares}', 'mes${cantFamiliares}' , 'anio${cantFamiliares}', 'familiar${cantFamiliares}')  ; arreglarFecha('mes${cantFamiliares}' , 'dia${cantFamiliares}','anio${cantFamiliares}')">Junio</li>
                                            <li class="separador">.</li>
                                            <li class="opcion" data-value="7" onclick="seleccionOpcion('mes${cantFamiliares}' , 7) ; compararFechaEdad('dia${cantFamiliares}', 'mes${cantFamiliares}' , 'anio${cantFamiliares}', 'familiar${cantFamiliares}')  ; arreglarFecha('mes${cantFamiliares}' , 'dia${cantFamiliares}','anio${cantFamiliares}')">Julio</li>
                                            <li class="separador">.</li>
                                            <li class="opcion" data-value="8" onclick="seleccionOpcion('mes${cantFamiliares}' , 8) ; compararFechaEdad('dia${cantFamiliares}', 'mes${cantFamiliares}' , 'anio${cantFamiliares}', 'familiar${cantFamiliares}')  ; arreglarFecha('mes${cantFamiliares}' , 'dia${cantFamiliares}','anio${cantFamiliares}')">Agosto</li>
                                            <li class="separador">.</li>
                                            <li class="opcion" data-value="9" onclick="seleccionOpcion('mes${cantFamiliares}' , 9) ; compararFechaEdad('dia${cantFamiliares}', 'mes${cantFamiliares}' , 'anio${cantFamiliares}', 'familiar${cantFamiliares}')  ; arreglarFecha('mes${cantFamiliares}' , 'dia${cantFamiliares}','anio${cantFamiliares}')">Septiembre</li>
                                            <li class="separador">.</li>
                                            <li class="opcion" data-value="10" onclick="seleccionOpcion('mes${cantFamiliares}' , 10) ; compararFechaEdad('dia${cantFamiliares}', 'mes${cantFamiliares}' , 'anio${cantFamiliares}', 'familiar${cantFamiliares}')  ; arreglarFecha('mes${cantFamiliares}' , 'dia${cantFamiliares}','anio${cantFamiliares}')">Octubre</li>
                                            <li class="separador">.</li>
                                            <li class="opcion" data-value="11" onclick="seleccionOpcion('mes${cantFamiliares}' , 11) ; compararFechaEdad('dia${cantFamiliares}', 'mes${cantFamiliares}' , 'anio${cantFamiliares}', 'familiar${cantFamiliares}')  ; arreglarFecha('mes${cantFamiliares}' , 'dia${cantFamiliares}','anio${cantFamiliares}')">Noviembre</li>
                                            <li class="separador">.</li>
                                            <li class="opcion" data-value="12" onclick="seleccionOpcion('mes${cantFamiliares}' , 12) ; compararFechaEdad('dia${cantFamiliares}', 'mes${cantFamiliares}' , 'anio${cantFamiliares}', 'familiar${cantFamiliares}')  ; arreglarFecha('mes${cantFamiliares}' , 'dia${cantFamiliares}','anio${cantFamiliares}')">Diciembre</li>
                                        </ul>
                                    </div>
                                    <p>del</p>
                                    <input type="text" class="input-anio" id="anio${cantFamiliares}" value="2000" minlength="4" maxlength="4" oninput="acomodarAnio('anio${cantFamiliares}') ; compararFechaEdad('dia${cantFamiliares}', 'mes${cantFamiliares}' , 'anio${cantFamiliares}', 'familiar${cantFamiliares}') ; if(this.value===''){this.value='0000'}   ; arreglarFecha('mes${cantFamiliares}' , 'dia${cantFamiliares}','anio${cantFamiliares}')" required oninput="this.value = this.value.replace(/\D/g,'')">
                                </div>
                            </div>

                            <div class="input-texto">
                                <input type="email" id="gmail${cantFamiliares}" placeholder=" " class="input-gmail" maxlength="30" minlength="8" required>
                                <label for="gmail${cantFamiliares}">Gmail</label>
                            </div>

                            <div class="input-texto">
                                <input type="text" class="input-numero-telefonico" id="numero-telefonico${cantFamiliares}" placeholder=" " maxlength="15" minlength="8" required oninput="this.value = this.value.replace(/\D/g,'')">
                                <label for="numero-telefonico${cantFamiliares}">Numero telefonico</label>
                            </div>

                            <div class="desplegable" tabindex="0" id="rol${cantFamiliares}">
                                <select class="select-oculto select-rol-familiar" required>
                                    <option value="">titulo</option>
                                    <option value="1">Conyuge</option>
                                    <option value="2">Hijo/a</option> 

                                    <option value="3">Padre</option>
                                    <option value="4">Madre</option> 

                                    <option value="5">Hermano/a</option>
                                    <option value="6">Abuelo/a</option> 

                                    <option value="7">Nieto/a</option>
                                    <option value="8">Tío/a</option> 

                                    <option value="9">Primo/a</option>
                                    <option value="10">otro</option> 
                                </select>

                                <p class="tipoDesplegable">Rol en la familia</p>
                                <p class="valorSeleccionado"></p>
                                <img src="../archivos/imagenes/flechita.svg" alt="">

                                <ul class="opciones">
                                    <li class="opcion" data-value="1" onclick="seleccionOpcion('rol${cantFamiliares}' , 1)">Cónyuge </li>
                                    <li class="separador">.</li>
                                    <li class="opcion" data-value="2" onclick="seleccionOpcion('rol${cantFamiliares}' , 2)">Hijo/a</li>
                                    <li class="separador">.</li>
                                    <li class="opcion" data-value="3" onclick="seleccionOpcion('rol${cantFamiliares}' , 3)">Padre</li>
                                    <li class="separador">.</li>
                                    <li class="opcion" data-value="4" onclick="seleccionOpcion('rol${cantFamiliares}' , 4)">Madre</li>
                                    <li class="separador">.</li>
                                    <li class="opcion" data-value="5" onclick="seleccionOpcion('rol${cantFamiliares}' , 5)">Hermano/a</li>
                                    <li class="separador">.</li>
                                    <li class="opcion" data-value="6" onclick="seleccionOpcion('rol${cantFamiliares}' , 6)">Abuelo/a</li>
                                    <li class="separador">.</li>
                                    <li class="opcion" data-value="7" onclick="seleccionOpcion('rol${cantFamiliares}' , 7)">Nieto/a</li>
                                    <li class="separador">.</li>
                                    <li class="opcion" data-value="8" onclick="seleccionOpcion('rol${cantFamiliares}' , 8)">Tío/a</li>
                                    <li class="separador">.</li>
                                    <li class="opcion" data-value="9" onclick="seleccionOpcion('rol${cantFamiliares}' , 9)">Primo/a</li>
                                    <li class="separador">.</li>
                                    <li class="opcion" data-value="10" onclick="seleccionOpcion('rol${cantFamiliares}' ,10)">Otro</li>
                                </ul>
                            </div>


                            <div class="desplegable" tabindex="0" id="genero${cantFamiliares}">
                                <select class="select-oculto select-genero"  required>
                                    <option value="">titulo</option>
                                    <option value="1">Masculino</option>
                                    <option value="2">Femenino</option> 
                                </select>

                                <p class="tipoDesplegable">Genero</p>
                                <p class="valorSeleccionado"></p>
                                <img src="../archivos/imagenes/flechita.svg" alt="">

                                <ul class="opciones">
                                    <li class="opcion" data-value="1" onclick="seleccionOpcion('genero${cantFamiliares}' , 1)">Masculino</li>
                                    <li class="separador">.</li>
                                    <li class="opcion" data-value="2" onclick="seleccionOpcion('genero${cantFamiliares}' , 2)">Femenino</li>
                                </ul>
                            </div>



                            <div class="input-archivo">
                                <input type="file" class="input-copia-cedula" id="CopiaCedulaFamiliar${cantFamiliares}" onchange="sincronizarNombreInput('CopiaCedulaFamiliar${cantFamiliares}')" required>
                                <button type="button" class="falso-input" onclick="simularClick('CopiaCedulaFamiliar${cantFamiliares}')" >Selecciona copia de la cedula</button>

                                <div class="edicion-archivo">
                                    <p id="CopiaCedulaFamiliar${cantFamiliares}Parrafo"></p>
                                    <button type="button" class="borrar" onclick="formatearInput('CopiaCedulaFamiliar${cantFamiliares}')">
                                        <img src="../archivos/imagenes/SimboloTachar.svg" alt="">
                                    </button>
                                </div>
                            </div>

                            <div class="input-archivo">
                                <input type="file" class="input-comprobante-ingresos" id="IngresosFamiliar${cantFamiliares}" onchange="sincronizarNombreInput('IngresosFamiliar${cantFamiliares}')" required>
                                <button type="button" class="falso-input" onclick="simularClick('IngresosFamiliar${cantFamiliares}')" >Selecciona Comprobante de ingresos</button>
                                <div class="edicion-archivo">
                                    <p id="IngresosFamiliar${cantFamiliares}Parrafo"></p>
                                    <button type="button" class="borrar" onclick="formatearInput('IngresosFamiliar${cantFamiliares}')">
                                        <img src="../archivos/imagenes/SimboloTachar.svg" alt="">
                                    </button>
                                </div>
                            </div>

                            <div class="input-archivo">
                                <input type="file" class="input-declaracion-no-vivienda" id="DeclaracionFamiliar${cantFamiliares}" onchange="sincronizarNombreInput('DeclaracionFamiliar${cantFamiliares}')" required>
                                <button type="button" class="falso-input" onclick="simularClick('DeclaracionFamiliar${cantFamiliares}')" >Selecciona la declaracion no vivienda</button>

                                <div class="edicion-archivo">
                                    <p id="DeclaracionFamiliar${cantFamiliares}Parrafo"></p>
                                    <button type="button" class="borrar" onclick="formatearInput('DeclaracionFamiliar${cantFamiliares}')">
                                        <img src="../archivos/imagenes/SimboloTachar.svg" alt="">
                                    </button>
                                </div>
                            </div>

                        </div>
                    </div>
                    
                    
                    
                    
                    <button type="button" class="desplegar-contraer-familiar boton-simple-azul" onclick="desplegarFamiliar('familiar${cantFamiliares}')">Desplegar Familiar</button>
                </div>
`);

}


async function obtenerFamiliar(familiarCedula) {
    try {
        const formData = new FormData();
        formData.append("cedula", familiarCedula);

        const resp = await fetch("../php/obtener_familiar.php", {
            method: "POST",
            body: formData
        });

        const data = await resp.json();
        return data;

    } catch (err) {
        console.error("Error de conexión o JSON:", err);
        return null;
    }
}


async function guardarFamiliarYSiguiente(cedula, urlDestino) {
    try {
        const familiar = await obtenerFamiliar(cedula);
        if (familiar) {
            sessionStorage.setItem('familiar', JSON.stringify(familiar));
            // redirigir solo después de guardar
            window.location.href = urlDestino;
        } else {
            console.error("No se encontró familiar adulto.");
        }
    } catch (err) {
        console.error("Error al obtener familiar:", err);
    }
}

function mostrarItems(selector) {
    const lista = document.querySelectorAll(selector);
    for (const elemento of lista) {
        elemento.style.display = "flex";
    }
}

// Devuelve el familiar guardado en sessionStorage como objeto
function obtenerFamiliarGuardado() {
    const familiarStr = sessionStorage.getItem('familiar');
    if (!familiarStr) return null; // si no existe, devuelve null
    try {
        return JSON.parse(familiarStr);
    } catch (e) {
        console.error("Error al parsear familiar guardado:", e);
        return null;
    }
}

function cerrarSesion() {
    sessionStorage.removeItem('familiar');
    window.location.href = "../html/index.html";
}

function mostrarPersona(persona) {
    const personaString = encodeURIComponent(JSON.stringify(persona));
    window.open("../html/perfil-persona.html?persona=" + personaString, "_blank");
    console.log("Objeto enviado:", persona);
}

const extensionesImagen = ["jpg", "jpeg", "png", "gif", "webp", "svg", "avif"];

function validarImagenInput(id) {
    const input = document.getElementById(id);
    const file = input.files[0]; // siempre hay un archivo
    const extension = file.name.split('.').pop().toLowerCase();

    if (!extensionesImagen.includes(extension)) {
        // borra el archivo y formatea
        formatearInput(id);        // tu función para limpiar/mostrar error
        sincronizarFotoInput(id);  // tu función de sincronización
                    
        if(!input.checkValidity()){
            datosValidos=false;            
            if (!input.parentNode.classList.contains("invalido-archivo")){
                input.parentNode.insertAdjacentHTML("beforeend", '<p class="mensaje-error">Debes ingresar una foto valida.</p>');
                input.parentNode.classList.add("invalido-archivo");
            }
        }else{
            if (input.parentNode.querySelector("p.mensaje-error") !== null){
                input.parentNode.classList.remove("invalido-archivo");
                input.parentNode.querySelector("p.mensaje-error").remove();
            }
        }

        return false;
     }

     return true; // todo OK
}

function arreglarFecha(inputMes, inputDia, inputAnio){
    mes=Number(document.getElementById(inputMes).querySelector('.select-mes').value) 
    const diaInput = document.getElementById(inputDia);
    const anio = Number(document.getElementById(inputAnio).value);
    console.log(mes , diaInput.value , anio)

    if ([4, 6, 9, 11].includes(mes)) {
        console.log("olas")
        if(diaInput.value > 30){
            diaInput.value = 30;
        }
    } else if (mes === 2) {
        console.log("ola")
        if(diaInput.value > 28){
            console.log("ola")
            if ((anio % 4 === 0) && (anio % 100 !== 0 || anio % 400 === 0)) {
                console.log((anio % 4 === 0) && (anio % 100 !== 0 || anio % 400 === 0))
                diaInput.value = 29;
                console.log("olas")
            } else {
                diaInput.value = 28;
                console.log("fuap")
            }
        }
    }
}

function confirmarAccion(mensaje) {
    return new Promise((resolve) => {
        const div = document.createElement('div');
        div.className = 'confirmacionAccion';
        div.innerHTML = `
            <div class="confirmacionBotones">
                <p>${mensaje}</p>
                <div class="botones">
                    <button id="confirmar">Confirmar</button>
                    <button id="cancelar">Cancelar</button>
                </div>
            </div>
        `;
        document.body.appendChild(div);

        div.querySelector('#confirmar').addEventListener('click', () => {
            resolve(true);
            div.remove();
        });
        div.querySelector('#cancelar').addEventListener('click', () => {
            resolve(false);
            div.remove();
        });
    });
}

function comprobarPermisos(){
    if(!usuario){
        console.log("usuario no registrado")
    }
}

function redirigir(direccion1 , direccion2 , mensaje1 , mensaje2){
    document.querySelector("body").insertAdjacentHTML('afterbegin', `
        <div class="confirmacionAccion redirigir">
        <div class="confirmacionBotones">
            <p>Enviado correctamente</p>
            <div class="botones">
                <a href="../html/${direccion1}" id="confirmar" class="boton-naranja">${mensaje1}</a>
                <a href="../html/${direccion2}" id="cancelar" class="boton-naranja">${mensaje2}</a>    
            </div>
        </div>
    </div>
    `);

}