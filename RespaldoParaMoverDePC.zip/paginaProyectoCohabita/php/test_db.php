<?php
$servername = "localhost";
$username = "root"; // por defecto en XAMPP
$password = "";     // por defecto en XAMPP
$dbname = "cohabita";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
echo "¡Conexión exitosa a la base de datos!";
$conn->close();
?>
