<?php
header('Content-Type: application/json; charset=utf-8');

$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'cohabita';

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die(json_encode(['error' => 'Conexión fallida: ' . $conn->connect_error], JSON_UNESCAPED_UNICODE));
}

$id_solicitud = $_POST['id_solicitud'] ?? null;
$id_admin = $_POST['id_admin'] ?? null;
$conclusion = $_POST['conclusion'] ?? null;
$razon = $_POST['razon_conclusion'] ?? null;

if (!$id_solicitud || !$id_admin || !$conclusion) {
    exit;
}

// 1. Insertar evaluación
$stmt = $conn->prepare("
    INSERT INTO admin_evalua_solicitud_registro
        (id_solicitud_registro, id_admin, fecha, conclusion, razon_conclusion)
    VALUES (?, ?, CURDATE(), ?, ?)
");
$stmt->bind_param("isss", $id_solicitud, $id_admin, $conclusion, $razon);
if (!$stmt->execute()) {
    exit;
}
$stmt->close();

// 2. Contar admins totales
$res = $conn->query("SELECT COUNT(*) AS total_admins FROM adulto WHERE rol = 'admin'");
$total_admins = $res->fetch_assoc()['total_admins'];
$res->close();

// 3. Contar votos actuales de la solicitud
$stmt = $conn->prepare("
    SELECT conclusion, COUNT(*) AS cantidad
    FROM admin_evalua_solicitud_registro
    WHERE id_solicitud_registro = ?
    GROUP BY conclusion
");
$stmt->bind_param("i", $id_solicitud);
$stmt->execute();
$res = $stmt->get_result();

$aprobados = 0;
$rechazados = 0;
while ($row = $res->fetch_assoc()) {
    if ($row['conclusion'] === 'aprobado') $aprobados = $row['cantidad'];
    elseif ($row['conclusion'] === 'rechazado') $rechazados = $row['cantidad'];
}
$stmt->close();

// 4. Determinar veredicto
$mayoria = floor($total_admins / 2) + 1; // más del 50%
$total_votos = $aprobados + $rechazados;
$nuevo_estado = null;

if ($aprobados >= $mayoria) {
    $nuevo_estado = 'aprobado';
} elseif ($rechazados >= $mayoria) {
    $nuevo_estado = 'rechazado';
} elseif ($total_votos == $total_admins) {
    // Todos votaron y no hay mayoría → desempate: aprobado si más aprobados, si empate exacto → rechazado
    $nuevo_estado = ($aprobados > $rechazados) ? 'aprobado' : 'rechazado';
} else {
    // Aún no se puede decidir
    $nuevo_estado = null;
}

if ($nuevo_estado) {
    // Obtener id_familia
    $stmt = $conn->prepare("SELECT id_familia FROM solicitud_registro WHERE id = ?");
    $stmt->bind_param("i", $id_solicitud);
    $stmt->execute();
    $id_familia = $stmt->get_result()->fetch_assoc()['id_familia'];
    $stmt->close();

    // Actualizar estado solicitud
    $stmt = $conn->prepare("UPDATE solicitud_registro SET estado = ? WHERE id = ?");
    $stmt->bind_param("si", $nuevo_estado, $id_solicitud);
    $stmt->execute();
    $stmt->close();

    // Actualizar estado familia
    $stmt = $conn->prepare("UPDATE familia SET estado = ? WHERE id = ?");
    $stmt->bind_param("si", $nuevo_estado, $id_familia);
    $stmt->execute();
    $stmt->close();

} else {
    // Todavía no hay veredicto → dejar en votación
    $stmt = $conn->prepare("SELECT id_familia FROM solicitud_registro WHERE id = ?");
    $stmt->bind_param("i", $id_solicitud);
    $stmt->execute();
    $id_familia = $stmt->get_result()->fetch_assoc()['id_familia'];
    $stmt->close();

    // Cambiar estado solicitud a en_votacion si estaba pendiente
    $stmt = $conn->prepare("UPDATE solicitud_registro SET estado = 'en_votacion' WHERE id = ? AND estado = 'pendiente'");
    $stmt->bind_param("i", $id_solicitud);
    $stmt->execute();
    $stmt->close();

    // Cambiar estado familia a pendiente si no estaba aprobado o rechazado
    $stmt = $conn->prepare("UPDATE familia SET estado = 'pendiente' WHERE id = ? AND estado NOT IN ('aprobado','rechazado')");
    $stmt->bind_param("i", $id_familia);
    $stmt->execute();
    $stmt->close();

}

$conn->close();
