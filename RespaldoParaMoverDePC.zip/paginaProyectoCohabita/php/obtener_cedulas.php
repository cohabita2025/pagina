<?php
// 🔹 Configuración de conexión
$servername = "localhost";
$username = "root";      // tu usuario de MySQL
$password = "";          // tu contraseña (si tenés)
$dbname = "cohabita";

header('Content-Type: application/json; charset=utf-8');

try {
    // 🔹 Crear conexión PDO
    $conn = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // 🔹 Consultar todas las cédulas de la tabla persona
    $stmt = $conn->query("SELECT cedula FROM persona");

    // 🔹 Obtener resultados como array asociativo
    $cedulas = $stmt->fetchAll(PDO::FETCH_COLUMN);

    // 🔹 Devolver en formato JSON
    echo json_encode([
        "status" => "success",
        "cantidad" => count($cedulas),
        "cedulas" => $cedulas
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

} catch (PDOException $e) {
    // 🔹 En caso de error, devolver mensaje claro
    echo json_encode([
        "status" => "error",
        "message" => "Error en la conexión o consulta: " . $e->getMessage()
    ]);
}
?>
