<?php 
error_reporting(E_ALL); 
ini_set("display_errors",1); 

$mysqli = new mysqli("localhost","root","","cohabita"); 
if($mysqli->connect_error) die("Error de conexión: ".$mysqli->connect_error);

// --------------------
// 1️⃣ Recibir datos
// --------------------
$familiaresTexto = json_decode($_POST['familiares_texto'] ?? '[]', true);

// ✅ Validar que no exista ninguna cédula
$cedulas = array_column($familiaresTexto,'cedula');
$placeholders = implode(',', array_fill(0, count($cedulas), '?'));
$tipos = str_repeat('s', count($cedulas));

if (!empty($cedulas)) {
    $stmt = $mysqli->prepare("SELECT cedula FROM persona WHERE cedula IN ($placeholders)");
    $stmt->bind_param($tipos, ...$cedulas);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res->num_rows > 0) {
        die("❌ Error: Una o más cédulas ya existen en la base de datos.");
    }
}

// --------------------
// 2️⃣ Crear familia
// --------------------
$mysqli->query("INSERT INTO familia (estado) VALUES ('pendiente')");
$idFamilia = $mysqli->insert_id;

// --------------------
// 3️⃣ Crear solicitud_registro
// --------------------
$fechaActual = date("Y-m-d");
$stmt = $mysqli->prepare("INSERT INTO solicitud_registro (fecha, estado, id_familia) VALUES (?, 'pendiente', ?)");
$stmt->bind_param("si", $fechaActual, $idFamilia);
$stmt->execute();

// --------------------
// 4️⃣ Crear carpeta base de familia
// --------------------
$baseDir = __DIR__ . '/../archivos/familias/';
$dirFamilia = $baseDir . $idFamilia . '/';
if(!file_exists($dirFamilia)) mkdir($dirFamilia,0777,true);

// --------------------
// 5️⃣ Recorrer familiares
// --------------------
foreach($familiaresTexto as $i => $f) {
    $cedula = $f['cedula'];
    $nombre = $f['nombre'];
    $primerApellido = $f['primerApellido'];
    $segundoApellido = $f['segundoApellido'];
    $genero = $f['genero'];
    
    // 🔹 Guardar la fecha tal cual llega desde JS, sin tocarla
    $fechaNacimiento = $f['fechaNacimiento'];

    // Carpeta personal
    $dirPersona = $dirFamilia . $cedula . '/';
    if(!file_exists($dirPersona)) mkdir($dirPersona,0777,true);

    // --------------------
    // Guardar archivos persona
    // --------------------
    $fotoNombre = null;
    $copiaCedulaNombre = null;

    if(isset($_FILES["foto_$i"]) && $_FILES["foto_$i"]['error'] === UPLOAD_ERR_OK){
        $ext = pathinfo($_FILES["foto_$i"]['name'], PATHINFO_EXTENSION);
        $fotoNombre = "foto_$cedula.$ext";
        move_uploaded_file($_FILES["foto_$i"]['tmp_name'], $dirPersona . $fotoNombre);
    }

    if(isset($_FILES["copiaCedula_$i"]) && $_FILES["copiaCedula_$i"]['error'] === UPLOAD_ERR_OK){
        $ext = pathinfo($_FILES["copiaCedula_$i"]['name'], PATHINFO_EXTENSION);
        $copiaCedulaNombre = "copiaCedula_$cedula.$ext";
        move_uploaded_file($_FILES["copiaCedula_$i"]['tmp_name'], $dirPersona . $copiaCedulaNombre);
    }

    // --------------------
    // Insertar en persona
    // --------------------
    $stmt = $mysqli->prepare(
        "INSERT INTO persona (cedula, nombre, primer_apellido, segundo_apellido, genero, fecha_nacimiento, copia_cedula, foto, id_familia) 
        VALUES (?,?,?,?,?,?,?,?,?)"
    );
    $stmt->bind_param("ssssssssi",$cedula,$nombre,$primerApellido,$segundoApellido,$genero,$fechaNacimiento,$copiaCedulaNombre,$fotoNombre,$idFamilia);
    $stmt->execute();

    // --------------------
    // Insertar en persona_integra_familia
    // --------------------
    $stmt = $mysqli->prepare("INSERT INTO persona_integra_familia (cedula_persona, rol, id_familia) VALUES (?,?,?)");
    $stmt->bind_param("ssi",$cedula,$f['rolEnFamilia'],$idFamilia);
    $stmt->execute();

    // --------------------
    // Si es adulto ➝ Insertar en adulto
    // --------------------
    if (!empty($f['correo']) || !empty($f['telefono']) || isset($_FILES["declaracionNoVivienda_$i"]) || isset($_FILES["comprobanteIngresos_$i"])) {
        $declaracionNombre = null;
        $reciboNombre = null;

        if(isset($_FILES["declaracionNoVivienda_$i"]) && $_FILES["declaracionNoVivienda_$i"]['error'] === UPLOAD_ERR_OK){
            $ext = pathinfo($_FILES["declaracionNoVivienda_$i"]['name'], PATHINFO_EXTENSION);
            $declaracionNombre = "declaracion_$cedula.$ext";
            move_uploaded_file($_FILES["declaracionNoVivienda_$i"]['tmp_name'], $dirPersona . $declaracionNombre);
        }

        if(isset($_FILES["comprobanteIngresos_$i"]) && $_FILES["comprobanteIngresos_$i"]['error'] === UPLOAD_ERR_OK){
            $ext = pathinfo($_FILES["comprobanteIngresos_$i"]['name'], PATHINFO_EXTENSION);
            $reciboNombre = "recibo_$cedula.$ext";
            move_uploaded_file($_FILES["comprobanteIngresos_$i"]['tmp_name'], $dirPersona . $reciboNombre);
        }

        $correo = $f['correo'] ?? null;
        $telefono = $f['telefono'] ?? null;
        $rol = $f['rol'] ?? null;
        $contrasenia = $f['contrasenia'] ?? null;

        $stmt = $mysqli->prepare(
            "INSERT INTO adulto (cedula, declaracion_no_vivienda, recibo_sueldo, correo, contrasenia, telefono, rol) 
            VALUES (?,?,?,?,?,?,?)"
        );
        $stmt->bind_param("sssssss",$cedula,$declaracionNombre,$reciboNombre,$correo,$contrasenia,$telefono,$rol);
        $stmt->execute();
    }
}

echo "✅ Datos insertados correctamente";
?>
