<?php
// Mostrar errores para depuración
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json');

require_once "config.php";

// Recibir cedula
$cedula = $_POST['cedula'] ?? '';

if (empty($cedula)) {
    echo json_encode(["error" => "No se recibió cédula"]);
    exit;
}

// Evitar inyección
$cedula = $conn->real_escape_string($cedula);

try {
    // Buscar en persona
    $sql = "SELECT * FROM persona WHERE cedula = '$cedula'";
    $res = $conn->query($sql);

    if (!$res || $res->num_rows === 0) {
        echo json_encode(["error" => "Familiar no encontrado"]);
        exit;
    }

    $persona = $res->fetch_assoc();

    // Buscar en adulto
    $sql = "SELECT cedula, declaracion_no_vivienda, recibo_sueldo, correo, telefono, rol 
            FROM adulto WHERE cedula = '$cedula'";
    $res = $conn->query($sql);

    if ($res && $res->num_rows > 0) {
        $adulto = $res->fetch_assoc();
        // Combinar datos
        $familiar = array_merge($persona, $adulto);
    } else {
        $familiar = $persona;
    }

    echo json_encode($familiar);

} catch (Exception $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
?>
