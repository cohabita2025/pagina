<?php
// --- DATOS DE CONEXIÓN ---
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'cohabita';

// Crear conexión
$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    http_response_code(500);
    exit;
}

// Validar POST y parámetros
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405); // Método no permitido
    exit;
}

$id_comprobante = $_POST['id_comprobante'] ?? null;
$id_admin = $_POST['id_admin'] ?? null;
$conclusion = $_POST['conclusion'] ?? null;
$razon = $_POST['razon_conclusion'] ?? null;

if (!$id_comprobante || !$id_admin || !$conclusion || !$razon) {
    http_response_code(400); // Bad request
    exit;
}

$id_comprobante = intval($id_comprobante);

// 1️⃣ Actualizar estado de comprobante_pago
$update = $conn->prepare("UPDATE comprobante_pago SET estado = ? WHERE id = ?");
$update->bind_param("si", $conclusion, $id_comprobante);
$update->execute();
$update->close();

// 2️⃣ Insertar validación del admin
$insert = $conn->prepare("
    INSERT INTO admin_valida_comprobante_pago 
    (id_comprobante_pago, id_admin, fecha, conclusion, razon_conclusion)
    VALUES (?, ?, CURDATE(), ?, ?)
");
$insert->bind_param("isss", $id_comprobante, $id_admin, $conclusion, $razon);
$insert->execute();
$insert->close();

$conn->close();

// ✅ Todo salió bien, no devolvemos JSON
http_response_code(200);
exit;
?>
