<?php
// Configuración de la base de datos
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'cohabita';

// Conectarse a MySQL sin seleccionar base de datos
$conn = new mysqli($host, $user, $pass);
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// 1️⃣ Borrar base de datos si existe
$sqlDrop = "DROP DATABASE IF EXISTS $dbname";
if ($conn->query($sqlDrop) === TRUE) {
    echo "Base de datos eliminada correctamente.<br>";
} else {
    echo "Error eliminando la base de datos: " . $conn->error . "<br>";
}

// 2️⃣ Crear la base de datos de nuevo con utf8mb4
$sqlCreate = "CREATE DATABASE $dbname CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci";
if ($conn->query($sqlCreate) === TRUE) {
    echo "Base de datos creada correctamente.<br>";
} else {
    echo "Error creando la base de datos: " . $conn->error . "<br>";
}

// 3️⃣ Seleccionar la nueva base de datos
$conn->select_db($dbname);

// 4️⃣ Leer tu archivo .sql y ejecutar las queries
$sqlFile = __DIR__ . '/../sql/cohabita.sql'; // Ajusta la ruta a tu archivo .sql

if (file_exists($sqlFile)) {
    $sqlContent = file_get_contents($sqlFile);

    // Separar queries por ; y ejecutar
    $queries = explode(";", $sqlContent);

    foreach ($queries as $query) {
        $query = trim($query);
        if ($query) {
            if ($conn->query($query) === FALSE) {
                echo "Error ejecutando query: " . $conn->error . "<br>";
            }
        }
    }

    echo "Base de datos restaurada desde el archivo .sql correctamente.";
} else {
    echo "No se encontró el archivo .sql en: $sqlFile";
}

$conn->close();
?>
