<?php
header('Content-Type: application/json; charset=utf-8');

$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'cohabita';

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die(json_encode(['error' => 'Conexión fallida: ' . $conn->connect_error], JSON_UNESCAPED_UNICODE));
}

$id_comprobante = $_POST['id_comprobante'] ?? null;
if (!$id_comprobante) {
    echo json_encode(['error' => 'No se proporcionó id_comprobante'], JSON_UNESCAPED_UNICODE);
    exit;
}

/* 1) Datos del comprobante */
$stmt = $conn->prepare("
    SELECT id AS id_comprobante, estado, monto, fecha, fecha_envio_comprobante, archivo_comprobante, cedula_emisor, cedula_titular
    FROM comprobante_pago
    WHERE id = ?
");
$stmt->bind_param("i", $id_comprobante);
$stmt->execute();
$comprobante = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$comprobante) {
    echo json_encode(['error' => 'Comprobante no encontrado'], JSON_UNESCAPED_UNICODE);
    exit;
}

/* 2) Datos del adulto/familia relacionado */
$stmt = $conn->prepare("
    SELECT 
        p.id_familia, 
        p.cedula, 
        p.nombre, 
        p.primer_apellido, 
        p.segundo_apellido, 
        p.genero, 
        p.fecha_nacimiento, 
        p.copia_cedula, 
        p.foto, 
        a.declaracion_no_vivienda, 
        a.recibo_sueldo, 
        a.correo, 
        a.telefono, 
        a.rol, 
        f.rol AS rol_familia
    FROM persona p
    LEFT JOIN adulto a ON a.cedula = p.cedula
    LEFT JOIN persona_integra_familia f 
        ON f.cedula_persona = p.cedula AND f.id_familia = p.id_familia
    WHERE p.cedula = ?
");
$stmt->bind_param("s", $comprobante['cedula_titular']);
$stmt->execute();
$adulto = $stmt->get_result()->fetch_assoc();
$stmt->close();

/* 3) Admins + evaluaciones de este comprobante (solo las que NO son 'pendiente') */
$stmt = $conn->prepare("
    SELECT
        a.cedula,
        p.nombre,
        p.primer_apellido,
        p.segundo_apellido,
        e.conclusion,
        COALESCE(e.razon_conclusion, '') AS razon_conclusion
    FROM adulto a
    JOIN persona p ON a.cedula = p.cedula
    JOIN admin_valida_comprobante_pago e
        ON e.id_admin = a.cedula 
        AND e.id_comprobante_pago = ?
        AND e.conclusion <> 'pendiente'
    WHERE a.rol = 'admin'
");
$stmt->bind_param("i", $id_comprobante);
$stmt->execute();
$evaluaciones = [];
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
    $evaluaciones[] = $row;
}
$stmt->close();

/* 4) Respuesta final */
echo json_encode([
    'comprobante' => $comprobante,
    'adulto' => $adulto,
    'evaluaciones' => $evaluaciones
], JSON_UNESCAPED_UNICODE);

$conn->close();
?>
